#define UTS_VERSION "#1 SMP Debian 6.1.94-1 (2024-06-21)"
